//
//  MapPin_Dhanmondi_.m
//  Restaurant Finder App_v-01
//
//  Created by MacBook Air on 13/11/18.
//  Copyright © 2018 MacBook Air. All rights reserved.
//

#import "MapPin.h"

@implementation MapPin
@synthesize coordinate,title,subtitle;
@end
