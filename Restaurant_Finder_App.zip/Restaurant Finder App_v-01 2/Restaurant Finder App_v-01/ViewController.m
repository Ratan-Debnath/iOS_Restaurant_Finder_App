//
//  ViewController.m
//  Restaurant Finder App_v-01
//
//  Created by MacBook Air on 9/11/18.
//  Copyright © 2018 MacBook Air. All rights reserved.
//

#import "ViewController.h"
#import "MapPin.h"
@interface ViewController ()

@end

@implementation ViewController
@synthesize mapview;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //2nd part of direction setup
    MKCoordinateRegion region ={{0.0, 0.0}, {0.0, 0.0}};
    region.center.latitude = 23.7392;
    region.center.longitude = 90.3754;
    region.span.longitudeDelta = 0.01f;
    region.span.latitudeDelta = 0.01f;
    [mapview setRegion:region animated:YES];
    
    MapPin *dhaka = [[MapPin alloc] init];
    dhaka.title = @"Dhaka";
    dhaka.subtitle = @"Bangladesh";
    dhaka.coordinate = region.center;
    [mapview addAnnotation:dhaka];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)Submit:(id)sender{
    self.myLabel.text = @"Submitted Successfully";
}

//Apple map control use switch case
-(IBAction)Setmap:(id)sender{
    switch (((UISegmentedControl *)sender).selectedSegmentIndex) {
        case 0:
            mapview.mapType = MKMapTypeStandard;
            break;
        case 1:
            mapview.mapType = MKMapTypeSatellite;
            break;
        case 2:
            mapview.mapType = MKMapTypeHybrid;
            break;
            
        default:
            break;
    }
}

// get user current location
-(IBAction)GetLocation:(id)sender{
    mapview.showsUserLocation = YES;
}

// go to direction
-(IBAction)Direction:(id)sender{
    NSString *urlString = @"https://maps.apple.com/?q=23.7392,90.3754";
    //use for google map as: @"http://maps.google.com/maps?daddr=23.7392,90.3754"

    // open url
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString] options:@{} completionHandler:nil];

}

// go to exact location
-(IBAction)TrumpCafe_Direction:(id)sender{
    NSString *urlString = @"https://www.google.com/maps/dir/23.7691715,90.3666602/Trump+Cafe,+Plot+No+60,+2nd+Floor+Keari+Crescent+Satmosjid+Road+2%2FA+Zigatola+Bus+Stand,+Dhaka+1209/@23.7537302,90.3537278,14z/data=!3m1!4b1!4m10!4m9!1m1!4e1!1m5!1m1!1s0x3755b8b5570285e1:0x28af126365c6c6a0!2m2!1d90.3754072!2d23.7392248!3e0";
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString] options:@{} completionHandler:nil];
}
-(IBAction)bbq_Direction:(id)sender{
    NSString *urlString = @"https://www.google.com/maps/dir/23.7691872,90.3666575/bbq+Bangladesh+Dhanmondi,+3rd+Floor,+67,+GH+Heights,+Shatmoshjid+Road+Opp+Bangladesh+Medical,+Dhaka+1209/@23.7584389,90.359708,15z/data=!3m1!4b1!4m10!4m9!1m1!4e1!1m5!1m1!1s0x3755bf4c3f48cb13:0x830b101788c33d1e!2m2!1d90.3686446!2d23.7498091!3e0";
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString] options:@{} completionHandler:nil];
    
}

-(IBAction)nawabi_Direction:(id)sender{
    NSString *urlString = @"https://www.google.com/maps/dir/23.7691818,90.3666321/mohammadpur+restaurant+list/@23.7653695,90.3504254,15z/data=!3m1!4b1!4m9!4m8!1m1!4e1!1m5!1m1!1s0x3755bf5f7c06efb5:0x36298314e6aa9909!2m2!1d90.3586797!2d23.7625121";
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString] options:@{} completionHandler:nil];
    
}
-(IBAction)arabian_Direction:(id)sender{
    NSString *urlString = @"https://www.google.com/maps/dir/23.7691755,90.366669/ARABIAN+Night,+Mohammadpur/@23.7665311,90.359573,16z/data=!3m1!4b1!4m9!4m8!1m1!4e1!1m5!1m1!1s0x3755c0a759e9edc5:0x1e4b57d062f7e835!2m2!1d90.3613548!2d23.7631709";
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString] options:@{} completionHandler:nil];
}

-(IBAction)nannaBirany_Direction:(id)sender{
    NSString *urlString = @"https://www.google.com/maps/dir/23.7691213,90.3667031/old+dhaka+restaurant/@23.7490309,90.3569872,13z/data=!3m1!4b1!4m9!4m8!1m1!4e1!1m5!1m1!1s0x3755b85988f1ef1b:0x200cd4973ac3585c!2m2!1d90.4170141!2d23.7290743";
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString] options:@{} completionHandler:nil];
    
}
-(IBAction)kalamKitchen_Direction:(id)sender{
    NSString *urlString = @"https://www.google.com/maps/dir/23.769181,90.3666267/kalam's+kitchen+old+dhaka+restaurant/@23.7412614,90.3541348,13z/data=!3m1!4b1!4m9!4m8!1m1!4e1!1m5!1m1!1s0x3755b9006c1a379b:0xca1a5cc985de2b9f!2m2!1d90.4117566!2d23.713356";
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString] options:@{} completionHandler:nil];
}
@end
