//
//  ViewController.h
//  Restaurant Finder App_v-01
//
//  Created by MacBook Air on 9/11/18.
//  Copyright © 2018 MacBook Air. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface ViewController : UIViewController
{
    MKMapView *mapview;
}

@property (nonatomic, retain) IBOutlet MKMapView *mapview;
@property (strong, nonatomic) IBOutlet UILabel *myLabel;


-(IBAction)Submit:(id)sender;

-(IBAction)Setmap:(id)sender;
-(IBAction)GetLocation:(id)sender;
-(IBAction)Direction:(id)sender;

-(IBAction)TrumpCafe_Direction:(id)sender;
-(IBAction)bbq_Direction:(id)sender;

-(IBAction)nawabi_Direction:(id)sender;
-(IBAction)arabian_Direction:(id)sender;

-(IBAction)nannaBirany_Direction:(id)sender;
-(IBAction)kalamKitchen_Direction:(id)sender;

@end

