//
//  AppDelegate.h
//  Restaurant Finder App_v-01
//
//  Created by MacBook Air on 9/11/18.
//  Copyright © 2018 MacBook Air. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

